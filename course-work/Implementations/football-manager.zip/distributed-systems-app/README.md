add migration: ```dotnet ef migrations add MigrationName --verbose --project FM.Data --startup-project FootballManager```
applying migration: ```dotnet ef database update --verbose --project FM.Data --startup-project FootballManager```

### MacOS

https://hasura.io/learn/database/microsoft-sql-server/installation/3-installing-mssql-mac/

https://devblogs.microsoft.com/azure-sql/development-with-sql-in-containers-on-macos/