﻿namespace HotelManager.DTOs
{
    public class RoomStatusDTO
    {
        public required string StatusName { get; set; }
    }
}
