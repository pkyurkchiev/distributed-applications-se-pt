﻿namespace HotelManager.Data
{
    public static class SeedRoles
    {
        public const string Admin = "Admin";

        public const string User = "User";
    }
}
