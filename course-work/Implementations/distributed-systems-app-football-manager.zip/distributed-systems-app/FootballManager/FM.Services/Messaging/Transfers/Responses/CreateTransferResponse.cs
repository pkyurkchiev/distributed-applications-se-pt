﻿using FM.Services.Messaging.Requests;

namespace FM.Services.Messaging.Responses;
public class CreateTransferResponse : ServiceResponseBase
{
	
}
