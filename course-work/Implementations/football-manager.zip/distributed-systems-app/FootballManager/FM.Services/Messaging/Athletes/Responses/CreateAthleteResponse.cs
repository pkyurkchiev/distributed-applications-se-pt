﻿namespace FM.Services.Messaging.Responses
{
	public class CreateAthleteResponse : ServiceResponseBase
	{
	}
}
