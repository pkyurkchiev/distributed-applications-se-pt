﻿namespace GustoHub.Data.ViewModels.PUT
{
    using System.ComponentModel.DataAnnotations;

    public class PUTOrderDishDto
    {
        public int Quantity { get; set; }
    }
}
