﻿namespace FM.Services.Messaging.Requests
{
	public class GetAllAthletesRequest : ServiceRequestBase
	{
		public GetAllAthletesRequest()
		{
		}
	}
}
