﻿namespace FM.Services.Messaging
{
	public abstract class ServiceRequestBase
	{
	}
}
