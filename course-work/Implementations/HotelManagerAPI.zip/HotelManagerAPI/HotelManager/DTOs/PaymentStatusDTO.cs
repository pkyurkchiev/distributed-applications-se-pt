﻿namespace HotelManager.DTOs
{
    public class PaymentStatusDTO
    {
        public required string StatusName { get; set; }
    }
}
