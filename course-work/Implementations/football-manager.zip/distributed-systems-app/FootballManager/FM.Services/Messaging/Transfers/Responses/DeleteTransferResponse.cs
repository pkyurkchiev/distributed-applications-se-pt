﻿namespace FM.Services.Messaging.Responses;
public class DeleteTransferResponse : ServiceResponseBase
{
	public BusinessStatusCodeEnum StatusCode { get; set; }
}
