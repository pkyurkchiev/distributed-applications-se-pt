﻿namespace FM.Services.Messaging.Requests;
public class GetAllTransfersRequest : ServiceRequestBase
{
}
