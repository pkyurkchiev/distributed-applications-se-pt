﻿namespace HotelManager.DTOs
{
    public class FeatureDTO
    {
        public required string FeatureName { get; set; }
    }
}
