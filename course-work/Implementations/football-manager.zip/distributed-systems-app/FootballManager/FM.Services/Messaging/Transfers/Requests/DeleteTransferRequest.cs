﻿namespace FM.Services.Messaging.Requests;
public class DeleteTransferRequest : ServiceRequestBase
{
	public int Id { get; set; }
}
